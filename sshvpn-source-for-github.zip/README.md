# GodarmX SSH (Android VpnService)

<img src="assets/logo.png" width="260">

SSH-only VPN app (Kotlin + Jetpack Compose). No OpenVPN code.

Traffic path:

    apps -> TUN (VpnService) -> hev-socks5-tunnel (JNI) -> local SOCKS5 127.0.0.1:1080
         -> SSH direct-tcpip channels (JSch) -> your SSH server

* DNS is answered by hev "mapdns" and resolved on the server side (SSH has no UDP).
* UDP traffic other than DNS is not supported (SOCKS5 UDP ASSOCIATE is rejected).

## Features
* Profiles: add / edit / delete, **Test** (TCP latency), copy as link, **Import** (one per line):
  `ssh://user:pass@host:22#Name` (add `?tls=1` for SSH+TLS) or `host:22@user:pass`
* Protocols: **SSH-Direct**, **SSH-Proxy** (HTTP/SOCKS5), **SSH-TLS** (server wraps SSH in TLS, SNI = host),
  **SSH-TLS-Proxy** (TLS through an HTTP CONNECT proxy)
* **UDPGW**: UDP over SSH via `badvpn-udpgw` on your server (`badvpn-udpgw --listen-addr 127.0.0.1:7300`).
  Written from the protocol description and not yet tested against a live server - treat as experimental.
* Authentication: password or private key
* Live upload/download speed and totals, speed in the notification
* Settings: speed in notification, in-app notifications, auto connect on select, vibrate, open logs on connect,
  **battery saver** (pause while screen off), **seamless tunnel** (block traffic while reconnecting),
  auto reconnect, connect after reboot, **auto-disconnect timer** (+30 min button), minimum TLS version,
  keep-alive, SOCKS port, About / acceptable use
* Profile list: search, delete all, share sheet
* Logs tab with copy/clear

## Build
**GitHub Actions (easiest):** push to `main`, open Actions -> "Build APK" -> download the artifact.
The workflow builds `libhev-socks5-tunnel.so` with the NDK, then the APK.

**Local:** build the .so yourself (see `.github/workflows/build.yml`), copy it to
`app/src/main/jniLibs/<abi>/`, then open the folder in Android Studio.

## Known limitations / TODO
* Host keys are not pinned (`StrictHostKeyChecking=no`); the fingerprint is written to the log.
* Profiles (incl. passwords) are stored in private SharedPreferences, not encrypted.
* Use only with servers you own or are authorised to use.

## Branding
Logo / icon / background are original vector art: `app/src/main/res/drawable/ic_launcher_foreground.xml`
(adaptive icon in `mipmap-anydpi-v26/`), background drawn in `AppBackground()` (ui/App.kt).
PNG previews are in `assets/`.
